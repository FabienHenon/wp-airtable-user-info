# airtable user info

Retrieve user information from Airtable 

## Usage

```
[airtable_user_info field_id='' default_value='']
```

* `field_id` : L'ID of the field to display
* `default_value` : Default value if no record is found for the user or if the field does not exist
